// string
let name = "Nathan Birch";

// number
let favoriteNumber = 5;

// object
let person = {
    name: "Nathan",
    favoriteNumber: 56,
    eyeColor: "blue",
    house: {
        address: "567 N Main",
        color: "blue",
        zip: 57575815
    },
    randomNumbers: [1,2,3,4,5]
}

// array
let heights = [60, 50, 48, 31, 75];

// function
function computeCircumference(r) {
    return Math.PI * r * r;
}

console.log(name);
console.log(favoriteNumber);
console.log(person);
console.log(heights);
console.log(computeCircumference(5));
let wakeUpImage = "https://t3.ftcdn.net/jpg/00/26/89/80/360_F_26898039_mly0Q4GjpW9mAlNPGKQN7jgQWwceWPl8.jpg";
let backgroundColor = "#000000";
let alarmSound = "assets/sleep.mp3";